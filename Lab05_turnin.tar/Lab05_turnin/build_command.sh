#!/usr/bin/sh

# Must be run in the project's root

iverilog ALU_test.v -I my_ALU
